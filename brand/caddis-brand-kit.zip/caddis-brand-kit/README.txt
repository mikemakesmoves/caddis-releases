Caddis brand kit
================

Files
- caddis-wordmark-black / -white (.svg, .png) — the Caddis wordmark. Use black on light backgrounds, white on dark.
- caddis-mark-black / -white (.svg, .png) — the caddisfly mark, for small spaces and avatars.
- caddis-app-icon-1024.png, -512.png — the macOS / Windows app icon.

Colours
- Ink    #111214
- Paper  #FFFFFF
- Blue   #4A8BFF
- Red    #FF5C5C
- Yellow #E6C244
- Green  #5DE6A1
- Purple #B46AFF

Using the logo
- Leave space around it, at least the height of the mark.
- Don't recolour, stretch, rotate or add effects to it.
- Write the name as "Caddis".

About Caddis
Caddis is a motion design tool with a timeline and a node graph side by side. Type, shapes, points, images and fields wire into each other freely, and it plays back as you build.

Questions: hello@caddis.app
https://caddis.app
