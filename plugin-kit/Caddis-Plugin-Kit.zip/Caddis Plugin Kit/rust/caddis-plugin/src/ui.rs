//! Plugin-drawn controls and viewer handles (PLUGIN-SDK.md §12a).
//!
//! A `custom` setting names a `draw` export and an `event` export. Caddis
//! calls `draw` with the setting's value and the control's size and gets a
//! [`DrawList`] back; it calls `event` when the user presses, drags or clicks,
//! and the plugin answers with a new value (and, if it likes, a new drawing).
//! Viewer handles (`"gizmos": [{ "type": "custom", … }]`) work the same way in
//! composition pixels. Plugins draw only in Caddis's own colours ([`Token`]).
//!
//! ```ignore
//! use caddis_plugin::*;
//!
//! fn bands_draw(req: &Request) -> Result<Response, String> {
//!     let [w, h] = req.ui_size();
//!     let lo: f64 = req.param_str("bands", "0.5").parse().unwrap_or(0.5);
//!     let mut d = DrawList::new();
//!     d.rect([0.0, 0.0, w, h], 0.0, Paint::fill(Token::Inset));
//!     d.line([lo * w, 0.0], [lo * w, h], Paint::stroke(Token::Accent, 1.0));
//!     d.handle([lo * w, h - 6.0], 5.0, "lo");
//!     Ok(Response::new().draw(d))
//! }
//!
//! fn bands_event(req: &Request) -> Result<Response, String> {
//!     match req.event() {
//!         Some(Event::Drag { handle, pos, .. }) if handle == "lo" => {
//!             let x = (pos[0] / req.ui_size()[0]).clamp(0.0, 1.0);
//!             Ok(Response::new().value(&format!("{x}")))
//!         }
//!         _ => Ok(Response::new()),
//!     }
//! }
//! ```

use alloc::string::{String, ToString};
use alloc::vec::Vec;

use crate::wire::{
    Align, DrawItem, HandleStyle, HistogramChannel, Paint, Request, Response, Token, Value,
};

impl Paint {
    /// A filled shape.
    pub fn fill(token: Token) -> Paint {
        Paint {
            token,
            alpha: 1.0,
            fill: true,
            width: 0.0,
        }
    }
    /// An outline `width` units wide.
    pub fn stroke(token: Token, width: f64) -> Paint {
        Paint {
            token,
            alpha: 1.0,
            fill: false,
            width,
        }
    }
    /// The same paint at an opacity (0–1).
    pub fn alpha(mut self, a: f64) -> Paint {
        self.alpha = a.clamp(0.0, 1.0);
        self
    }
}

/// Shapes for Caddis to draw, in order.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct DrawList(pub Vec<DrawItem>);

impl DrawList {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn rect(&mut self, rect: [f64; 4], radius: f64, paint: Paint) -> &mut Self {
        self.0.push(DrawItem::Rect {
            rect,
            radius,
            paint,
        });
        self
    }
    pub fn line(&mut self, a: [f64; 2], b: [f64; 2], paint: Paint) -> &mut Self {
        self.0.push(DrawItem::Line { a, b, paint });
        self
    }
    pub fn polyline(&mut self, points: &[[f64; 2]], closed: bool, paint: Paint) -> &mut Self {
        self.0.push(DrawItem::Polyline {
            points: points.to_vec(),
            closed,
            paint,
        });
        self
    }
    /// A filled polygon.
    pub fn polygon(&mut self, points: &[[f64; 2]], paint: Paint) -> &mut Self {
        self.polyline(points, true, paint)
    }
    pub fn ellipse(&mut self, center: [f64; 2], radii: [f64; 2], paint: Paint) -> &mut Self {
        self.0.push(DrawItem::Ellipse {
            center,
            radii,
            paint,
        });
        self
    }
    /// Text in Caddis's interface font, placed by `align` at `pos`.
    pub fn text(
        &mut self,
        pos: [f64; 2],
        text: &str,
        size: f64,
        align: Align,
        paint: Paint,
    ) -> &mut Self {
        self.0.push(DrawItem::Text {
            pos,
            text: text.to_string(),
            size,
            align,
            paint,
        });
        self
    }
    /// A handle in a particular style: [`HandleStyle::Square`] for a curve's
    /// end points, `Tangent` for bezier handles, `BarV` / `BarH` for edges,
    /// `Hidden` for a grab area over a mark you draw yourself.
    pub fn handle_styled(
        &mut self,
        pos: [f64; 2],
        radius: f64,
        id: &str,
        style: HandleStyle,
    ) -> &mut Self {
        self.0.push(DrawItem::StyledHandle {
            pos,
            radius,
            id: id.to_string(),
            style,
        });
        self
    }
    /// The node's input histogram in Caddis's own look (the same as Levels
    /// and Curves), inside `rect`. Needs `"histogram": true` on the setting.
    /// Use [`Request::ui_histogram`] instead only to draw something custom.
    pub fn histogram(&mut self, rect: [f64; 4], channel: HistogramChannel) -> &mut Self {
        self.0.push(DrawItem::Histogram { rect, channel });
        self
    }
    /// An invisible rectangular grab area: drag anywhere inside it to drag
    /// `id`. Add it BEFORE the handles inside it so they stay on top; use
    /// the drag event's `step` to move what it stands for.
    pub fn handle_area(&mut self, rect: [f64; 4], id: &str) -> &mut Self {
        self.0.push(DrawItem::HandleArea {
            rect,
            id: id.to_string(),
        });
        self
    }
    /// A draggable handle (Caddis draws and hit-tests it; drags arrive as
    /// [`Event::Drag`] with this `id`).
    pub fn handle(&mut self, pos: [f64; 2], radius: f64, id: &str) -> &mut Self {
        self.0.push(DrawItem::Handle {
            pos,
            radius,
            id: id.to_string(),
        });
        self
    }
}

/// Which part of a drag an event is.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Phase {
    Begin,
    Move,
    End,
}

/// Modifier keys held during an event.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Mods {
    pub shift: bool,
    pub alt: bool,
    /// ⌘ on macOS, Ctrl elsewhere.
    pub command: bool,
}

/// A key a control can ask for with `"keys"` in its manifest entry.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[non_exhaustive]
pub enum Key {
    /// Delete or Backspace.
    Delete,
    Escape,
    Enter,
    Left,
    Right,
    Up,
    Down,
}

impl Key {
    /// The name the manifest's `"keys"` list uses.
    pub fn name(self) -> &'static str {
        match self {
            Key::Delete => "delete",
            Key::Escape => "escape",
            Key::Enter => "enter",
            Key::Left => "left",
            Key::Right => "right",
            Key::Up => "up",
            Key::Down => "down",
        }
    }

    fn from_name(name: &str) -> Option<Key> {
        Some(match name {
            "delete" => Key::Delete,
            "escape" => Key::Escape,
            "enter" => Key::Enter,
            "left" => Key::Left,
            "right" => Key::Right,
            "up" => Key::Up,
            "down" => Key::Down,
            _ => return None,
        })
    }
}

/// What the user did. Positions are in the drawing's coordinates.
///
/// Caddis may add kinds of event: keep a `_ =>` arm in your `match`.
#[derive(Debug, Clone, PartialEq)]
#[non_exhaustive]
pub enum Event {
    /// A handle (or, with an empty `handle`, the background) is being dragged.
    Drag {
        handle: String,
        pos: [f64; 2],
        /// How far the pointer moved since the last event your plugin
        /// received. Add it to move something BY the pointer's motion (a
        /// range dragged by its middle); the settings in this request already
        /// include every earlier step, even when Caddis skipped moves.
        step: [f64; 2],
        phase: Phase,
        mods: Mods,
    },
    Click {
        pos: [f64; 2],
        mods: Mods,
    },
    DoubleClick {
        pos: [f64; 2],
        mods: Mods,
    },
    Wheel {
        pos: [f64; 2],
        delta: [f64; 2],
        mods: Mods,
    },
    /// A key was pressed while the control had keyboard focus (it takes focus
    /// when pressed). Sent only for the keys the setting lists in `"keys"`;
    /// Caddis keeps those keys from the rest of the app while the control is
    /// focused, so list only the ones you act on.
    ///
    /// A control keeps no state between calls, so Caddis says what the key is
    /// about: `handle` is the handle last pressed (empty when the last press
    /// was on the background), and `pos` is where the pointer last was with a
    /// button down — after a click that added something, that is the thing's
    /// place. After a [`Key::Delete`], Caddis forgets the handle, so a second
    /// press never names a handle that may by then be another item.
    Key {
        key: Key,
        handle: String,
        pos: [f64; 2],
        mods: Mods,
    },
}

impl Request {
    /// The control's size (control px), or for a viewer handle the
    /// composition size.
    pub fn ui_size(&self) -> [f64; 2] {
        match self.input("@ui.size") {
            Some(Value::Vec2(v)) => *v,
            _ => [0.0, 0.0],
        }
    }
    /// Viewer handles: composition pixels per screen pixel, so strokes and
    /// handles can stay the same size on screen at any zoom (1 for controls).
    pub fn ui_scale(&self) -> f64 {
        match self.input("@ui.scale") {
            Some(Value::Scalar(v)) => *v,
            _ => 1.0,
        }
    }
    /// The node's input histogram, for a `custom` setting with
    /// `"histogram": true`: 256 bins each of red, green, blue and luminance,
    /// normalised 0–1. `None` until Caddis has rendered the node once (and
    /// during playback, when histograms aren't computed).
    pub fn ui_histogram(&self) -> Option<[&[f64]; 4]> {
        match self.input("@ui.histogram") {
            Some(Value::Floats(v)) if v.len() == 1024 => {
                Some([&v[0..256], &v[256..512], &v[512..768], &v[768..1024]])
            }
            _ => None,
        }
    }
    /// The event being handled (an `event` call), if any.
    pub fn event(&self) -> Option<Event> {
        let s = |k: &str| match self.input(k) {
            Some(Value::String(s)) => s.as_str(),
            _ => "",
        };
        let v2 = |k: &str| match self.input(k) {
            Some(Value::Vec2(v)) => *v,
            _ => [0.0, 0.0],
        };
        let bits = match self.input("@event.mods") {
            Some(Value::Scalar(b)) => *b as u32,
            _ => 0,
        };
        let mods = Mods {
            shift: bits & 1 != 0,
            alt: bits & 2 != 0,
            command: bits & 4 != 0,
        };
        let pos = v2("@event.pos");
        Some(match s("@event.kind") {
            "drag" => Event::Drag {
                handle: s("@event.handle").to_string(),
                pos,
                step: v2("@event.step"),
                phase: match s("@event.phase") {
                    "begin" => Phase::Begin,
                    "end" => Phase::End,
                    _ => Phase::Move,
                },
                mods,
            },
            "click" => Event::Click { pos, mods },
            "double_click" => Event::DoubleClick { pos, mods },
            "wheel" => Event::Wheel {
                pos,
                delta: v2("@event.delta"),
                mods,
            },
            "key" => Event::Key {
                key: Key::from_name(s("@event.key"))?,
                handle: s("@event.handle").to_string(),
                pos,
                mods,
            },
            _ => return None,
        })
    }
}

impl Response {
    /// What the control (or viewer handle) looks like now.
    pub fn draw(mut self, list: DrawList) -> Self {
        self.outputs
            .push(("@draw".to_string(), Value::Draw(list.0)));
        self
    }
    /// From an `event` call: the setting's new value. Caddis stores it, keys
    /// it if the setting is animated, and folds a whole drag into one undo
    /// step.
    pub fn value(mut self, v: &str) -> Self {
        self.outputs
            .push(("@value".to_string(), Value::String(v.to_string())));
        self
    }
    /// From a `bake` call: the lookup shaders read through `@param.<id>`,
    /// RGBA per entry (`size × 4` numbers).
    pub fn bake(mut self, rgba: Vec<f64>) -> Self {
        self.outputs.push(("@lut".to_string(), Value::Floats(rgba)));
        self
    }
}
