//! Write the CPU half of a Caddis plugin node in Rust.
//!
//! A plugin's `logic.wasm` exports one function per node that has `logic`
//! in its manifest. Caddis calls it once per evaluation with the node's
//! non-image inputs and resolved params; it returns the node's non-image
//! outputs (points, shapes, values). It runs sandboxed: no files, network,
//! clock or randomness — the same inputs always give the same outputs, which
//! is what makes scrubbing and caching safe. Images never reach WebAssembly;
//! they stay on the GPU, in the node's passes.
//!
//! ```ignore
//! use caddis_plugin::*;
//!
//! fn jitter(req: &Request) -> Result<Response, String> {
//!     let mut pts = req.points("points").cloned().unwrap_or_default();
//!     let amount = req.param_f64("amount", 5.0);
//!     for (i, p) in pts.positions.iter_mut().enumerate() {
//!         let r = hash01(pts.ids[i], 1);
//!         p[0] += (r - 0.5) * 2.0 * amount;
//!     }
//!     Ok(Response::new().output("out", Value::Points(pts)))
//! }
//!
//! caddis_plugin::entry!(jitter => jitter);
//! ```
//!
//! Build with `cargo build --release --target wasm32-unknown-unknown` and
//! point the manifest's `"wasm"` at the `.wasm` file. Wire format:
//! [`wire`]. Design: `PLUGIN-SDK.md` §7.

#![no_std]
extern crate alloc;

pub mod ui;
pub mod wire;

use alloc::format;
use alloc::string::{String, ToString};
use alloc::vec::Vec;

pub use ui::*;
pub use wire::*;

impl Request {
    pub fn input(&self, port: &str) -> Option<&Value> {
        self.inputs.iter().find(|(k, _)| k == port).map(|(_, v)| v)
    }
    pub fn param(&self, id: &str) -> Option<&Value> {
        self.params.iter().find(|(k, _)| k == id).map(|(_, v)| v)
    }
    /// A number setting, or `default` (bools read as 0 / 1; enums are text —
    /// use [`param_str`](Self::param_str)).
    pub fn param_f64(&self, id: &str, default: f64) -> f64 {
        match self.param(id) {
            Some(Value::Scalar(v)) => *v,
            Some(Value::Bool(b)) => *b as u8 as f64,
            _ => default,
        }
    }
    pub fn param_bool(&self, id: &str, default: bool) -> bool {
        match self.param(id) {
            Some(Value::Bool(b)) => *b,
            Some(Value::Scalar(v)) => *v != 0.0,
            _ => default,
        }
    }
    /// A text setting (string, text, file, enum, custom), or `default`.
    pub fn param_str<'a>(&'a self, id: &str, default: &'a str) -> &'a str {
        match self.param(id) {
            Some(Value::String(s)) => s,
            _ => default,
        }
    }
    pub fn param_vec2(&self, id: &str, default: [f64; 2]) -> [f64; 2] {
        match self.param(id) {
            Some(Value::Vec2(v)) => *v,
            Some(Value::Scalar(s)) => [*s, *s],
            _ => default,
        }
    }
    pub fn param_color(&self, id: &str, default: [f64; 4]) -> [f64; 4] {
        match self.param(id) {
            Some(Value::Color(c)) => *c,
            _ => default,
        }
    }
    pub fn points(&self, port: &str) -> Option<&Points> {
        match self.input(port) {
            Some(Value::Points(p)) => Some(p),
            Some(Value::Shape(s)) => Some(&s.points),
            _ => None,
        }
    }
    pub fn shape(&self, port: &str) -> Option<&Shape> {
        match self.input(port) {
            Some(Value::Shape(s)) => Some(s),
            _ => None,
        }
    }
}

impl Response {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn output(mut self, port: &str, value: Value) -> Self {
        self.outputs.push((port.to_string(), value));
        self
    }
    /// Override a param for this node's GPU passes this frame.
    pub fn uniform(mut self, param: &str, value: Value) -> Self {
        self.outputs.push((format!("params.{param}"), value));
        self
    }
    /// From a button's `action`: change a setting (one undo step for the
    /// whole action, keyframed at the playhead if the setting is animated).
    pub fn set(self, param: &str, value: Value) -> Self {
        self.uniform(param, value)
    }
    pub fn log(mut self, message: impl Into<String>) -> Self {
        self.logs.push(message.into());
        self
    }
}

impl Points {
    pub fn len(&self) -> usize {
        self.ids.len()
    }
    pub fn is_empty(&self) -> bool {
        self.ids.is_empty()
    }
    /// Append a point with a fresh id; extends every attribute column with
    /// zeros so the columns stay as long as `ids`.
    pub fn push(&mut self, position: [f64; 2]) -> u32 {
        let id = self.next_id;
        self.next_id += 1;
        self.ids.push(id);
        self.positions.push(position);
        for (_, a) in self.attributes.iter_mut() {
            match a {
                Attr::Scalar(v) => v.push(0.0),
                Attr::Vec2(v) => v.push([0.0; 2]),
                Attr::Vec3(v) => v.push([0.0; 3]),
                Attr::Vec4(v) => v.push([0.0; 4]),
            }
        }
        id
    }
    pub fn attr(&self, name: &str) -> Option<&Attr> {
        self.attributes
            .iter()
            .find(|(k, _)| k == name)
            .map(|(_, a)| a)
    }
    pub fn attr_mut(&mut self, name: &str) -> Option<&mut Attr> {
        self.attributes
            .iter_mut()
            .find(|(k, _)| k == name)
            .map(|(_, a)| a)
    }
    /// A scalar column, created (zero-filled) if missing or of another kind.
    pub fn scalar_column(&mut self, name: &str) -> &mut Vec<f64> {
        let n = self.ids.len();
        if !matches!(self.attr(name), Some(Attr::Scalar(v)) if v.len() == n) {
            self.set_attr(name, Attr::Scalar(alloc::vec![0.0; n]));
        }
        match self.attr_mut(name) {
            Some(Attr::Scalar(v)) => v,
            _ => unreachable!(),
        }
    }
    /// A vec2 column, created (zero-filled) if missing or of another kind.
    pub fn vec2_column(&mut self, name: &str) -> &mut Vec<[f64; 2]> {
        let n = self.ids.len();
        if !matches!(self.attr(name), Some(Attr::Vec2(v)) if v.len() == n) {
            self.set_attr(name, Attr::Vec2(alloc::vec![[0.0; 2]; n]));
        }
        match self.attr_mut(name) {
            Some(Attr::Vec2(v)) => v,
            _ => unreachable!(),
        }
    }
    /// Set (or replace) a column. It must be as long as the point list.
    pub fn set_attr(&mut self, name: &str, column: Attr) {
        match self.attributes.iter_mut().find(|(k, _)| k == name) {
            Some((_, a)) => *a = column,
            None => self.attributes.push((name.to_string(), column)),
        }
    }
    /// Keep only the rows where `keep(row)` is true, in every column.
    pub fn retain_rows(&mut self, mut keep: impl FnMut(usize) -> bool) {
        let mask: Vec<bool> = (0..self.ids.len()).map(&mut keep).collect();
        fn filt<T: Copy>(v: &mut Vec<T>, mask: &[bool]) {
            let mut i = 0;
            v.retain(|_| {
                let k = mask[i];
                i += 1;
                k
            });
        }
        filt(&mut self.ids, &mask);
        filt(&mut self.positions, &mask);
        for (_, a) in self.attributes.iter_mut() {
            match a {
                Attr::Scalar(v) => filt(v, &mask),
                Attr::Vec2(v) => filt(v, &mask),
                Attr::Vec3(v) => filt(v, &mask),
                Attr::Vec4(v) => filt(v, &mask),
            }
        }
    }
}

/// Deterministic random in [0, 1) for a point id and seed (splitmix64).
/// Key per-element randomness on ids — row positions change whenever a
/// point is added or removed upstream.
pub fn hash01(id: u32, seed: u64) -> f64 {
    let mut z = (id as u64) ^ seed.wrapping_mul(0x9E37_79B9_7F4A_7C15);
    z = z.wrapping_add(0x9E37_79B9_7F4A_7C15);
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    z ^= z >> 31;
    (z >> 11) as f64 / (1u64 << 53) as f64
}

/// Export the allocator Caddis uses to hand over requests, plus one
/// function per node: `entry!(export_name => your_fn, …)`.
#[macro_export]
macro_rules! entry {
    ($($export:ident => $func:path),* $(,)?) => {
        #[no_mangle]
        pub extern "C" fn caddis_alloc(len: u32) -> u32 {
            $crate::__alloc(len)
        }
        $(
            // Exported under the given name without claiming that name in
            // Rust, so `entry!(jitter => jitter)` doesn't collide.
            const _: () = {
                #[export_name = stringify!($export)]
                pub extern "C" fn __caddis_entry(ptr: u32, len: u32) -> u64 {
                    $crate::__call(ptr, len, $func)
                }
            };
        )*
    };
}

#[doc(hidden)]
pub fn __alloc(len: u32) -> u32 {
    let mut v: Vec<u8> = Vec::with_capacity(len as usize);
    let p = v.as_mut_ptr();
    core::mem::forget(v);
    p as usize as u32
}

#[doc(hidden)]
pub fn __call(ptr: u32, len: u32, f: fn(&Request) -> Result<Response, String>) -> u64 {
    // SAFETY: the host wrote `len` bytes at `ptr`, which it got from
    // `caddis_alloc(len)` in this same instance.
    let bytes = unsafe { core::slice::from_raw_parts(ptr as usize as *const u8, len as usize) };
    let response = match decode_request(bytes) {
        Ok(req) => f(&req).unwrap_or_else(|e| Response {
            error: e,
            ..Default::default()
        }),
        Err(e) => Response {
            error: format!("bad request: {}", e.0),
            ..Default::default()
        },
    };
    let out = encode_response(&response);
    let p = out.as_ptr() as usize as u64;
    let l = out.len() as u64;
    core::mem::forget(out);
    (p << 32) | l
}
