//! The bytes Caddis and a plugin's WebAssembly exchange — one request in,
//! one response out. Little-endian, length-prefixed, versioned by the magic.
//! The engine links this exact module, so the two sides cannot disagree.
//!
//! ```text
//! request  = "CPQ1" str(node) context u32(n) n×(str(port) value) u32(m) m×(str(id) value)
//! response = "CPR1" u32(n) n×(str(port) value) u32(k) k×str(log) str(error)
//! context  = f64 frame, time, fps, comp_width, comp_height, layer_frame, seed
//! value    = u8 tag + payload (see `Value`)
//! ```

use alloc::string::String;
use alloc::vec::Vec;

/// Values that cross the boundary. Images never do — they stay on the GPU
/// and are handled by the plugin's passes.
#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    None,
    Scalar(f64),
    Vec2([f64; 2]),
    Vec3([f64; 3]),
    /// Straight-alpha linear RGBA.
    Color([f64; 4]),
    Bool(bool),
    String(String),
    Points(Points),
    Shape(Shape),
    /// What a plugin-drawn control or viewer handle looks like — see
    /// [`DrawItem`]. Caddis draws it; the plugin never touches pixels.
    Draw(Vec<DrawItem>),
    /// Plain numbers: a control's baked lookup, RGBA per entry.
    Floats(Vec<f64>),
}

/// The colours a plugin may draw with — Caddis's own theme roles. There is
/// deliberately no free colour: every plugin's controls look like Caddis.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum Token {
    /// Primary text and strokes.
    Text = 0,
    /// Secondary text, histograms, inactive marks.
    Muted = 1,
    /// Tertiary text, grid lines.
    Subtle = 2,
    /// Borders and dividers.
    Edge = 3,
    /// Selection and active marks (Caddis cream).
    Accent = 4,
    /// Keyframe / emphasis (amber).
    Keyframe = 5,
    /// Viewer handles (gizmo amber).
    Gizmo = 6,
    /// The control's sunken background.
    Inset = 7,
}

impl Token {
    pub fn from_u8(v: u8) -> Option<Token> {
        Some(match v {
            0 => Token::Text,
            1 => Token::Muted,
            2 => Token::Subtle,
            3 => Token::Edge,
            4 => Token::Accent,
            5 => Token::Keyframe,
            6 => Token::Gizmo,
            7 => Token::Inset,
            _ => return None,
        })
    }
}

/// How a shape is painted: one of the theme [`Token`]s, at an opacity,
/// filled or stroked.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Paint {
    pub token: Token,
    /// 0–1.
    pub alpha: f64,
    pub fill: bool,
    /// Stroke width in the drawing's units (control px, or comp px for
    /// viewer handles — multiply by `ui_scale()` for a fixed screen width).
    pub width: f64,
}

/// One thing to draw. Coordinates: control pixels from the top-left for a
/// control; composition pixels from the comp centre (+y down) for a viewer
/// handle.
#[derive(Debug, Clone, PartialEq)]
pub enum DrawItem {
    Rect {
        rect: [f64; 4],
        radius: f64,
        paint: Paint,
    },
    Line {
        a: [f64; 2],
        b: [f64; 2],
        paint: Paint,
    },
    Polyline {
        points: Vec<[f64; 2]>,
        closed: bool,
        paint: Paint,
    },
    Ellipse {
        center: [f64; 2],
        radii: [f64; 2],
        paint: Paint,
    },
    Text {
        pos: [f64; 2],
        text: String,
        size: f64,
        align: Align,
        paint: Paint,
    },
    /// A draggable handle in Caddis's handle style. Caddis hit-tests it and
    /// reports drags by `id`.
    Handle {
        pos: [f64; 2],
        radius: f64,
        id: String,
    },
    /// The node's input histogram, drawn by Caddis in its own histogram look
    /// (the same as Levels and Curves) inside `rect` `[x, y, w, h]`. Needs
    /// `"histogram": true` on the setting; draws nothing until there is one.
    Histogram {
        rect: [f64; 4],
        channel: HistogramChannel,
    },
    /// An invisible rectangular grab area `[x, y, w, h]`: drags inside it
    /// arrive as [`crate::Event::Drag`] with this `id` (e.g. moving a whole
    /// range by its middle). Items drawn later sit on top of it.
    HandleArea { rect: [f64; 4], id: String },
    /// A draggable handle with a chosen look (see [`HandleStyle`]).
    StyledHandle {
        pos: [f64; 2],
        radius: f64,
        id: String,
        style: HandleStyle,
    },
}

/// Where text sits relative to its position.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum Align {
    Left = 0,
    Center = 1,
    Right = 2,
}

impl Align {
    pub fn from_u8(v: u8) -> Option<Align> {
        Some(match v {
            0 => Align::Left,
            1 => Align::Center,
            2 => Align::Right,
            _ => return None,
        })
    }
}

/// Which part of the histogram Caddis draws.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum HistogramChannel {
    /// Luminance, with red / green / blue as thin lines over it.
    Master = 0,
    /// Luminance alone.
    Luma = 1,
    Red = 2,
    Green = 3,
    Blue = 4,
}

impl HistogramChannel {
    pub fn from_u8(v: u8) -> Option<HistogramChannel> {
        Some(match v {
            0 => HistogramChannel::Master,
            1 => HistogramChannel::Luma,
            2 => HistogramChannel::Red,
            3 => HistogramChannel::Green,
            4 => HistogramChannel::Blue,
            _ => return None,
        })
    }
}

/// How Caddis draws a handle. Every style is drawn by Caddis (dark fill,
/// accent ring, filled while dragged), so plugin controls match Caddis's own.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum HandleStyle {
    /// A round point — the default, as on Caddis's Curves editor.
    Dot = 0,
    /// A square point: a curve's anchor / end point.
    Square = 1,
    /// A small solid dot: a bezier tangent handle.
    Tangent = 2,
    /// A vertical bar: an edge you drag left and right.
    BarV = 3,
    /// A horizontal bar: an edge you drag up and down.
    BarH = 4,
    /// Nothing drawn: a grab area only, for when the plugin draws the mark
    /// itself. `radius` is the area's size.
    Hidden = 5,
}

impl HandleStyle {
    pub fn from_u8(v: u8) -> Option<HandleStyle> {
        Some(match v {
            0 => HandleStyle::Dot,
            1 => HandleStyle::Square,
            2 => HandleStyle::Tangent,
            3 => HandleStyle::BarV,
            4 => HandleStyle::BarH,
            5 => HandleStyle::Hidden,
            _ => return None,
        })
    }
}

/// A point cloud: parallel columns, one row per point. `ids` are stable
/// identities (key per-point randomness on them, never on the row index);
/// `next_id` is the first id not yet used.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Points {
    pub ids: Vec<u32>,
    pub positions: Vec<[f64; 2]>,
    pub next_id: u32,
    /// Named per-point columns (`scale`, `rotation`, `color`, `velocity`…),
    /// each as long as `ids`.
    pub attributes: Vec<(String, Attr)>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum Attr {
    Scalar(Vec<f64>),
    Vec2(Vec<[f64; 2]>),
    Vec3(Vec<[f64; 3]>),
    Vec4(Vec<[f64; 4]>),
}

impl Attr {
    pub fn len(&self) -> usize {
        match self {
            Attr::Scalar(v) => v.len(),
            Attr::Vec2(v) => v.len(),
            Attr::Vec3(v) => v.len(),
            Attr::Vec4(v) => v.len(),
        }
    }
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

/// One value for a whole path or shape.
#[derive(Debug, Clone, PartialEq)]
pub enum AttrValue {
    Scalar(f64),
    Vec2([f64; 2]),
    Vec3([f64; 3]),
    Vec4([f64; 4]),
    String(String),
}

/// Paths over a point set. Segments reference points by id.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Shape {
    pub points: Points,
    pub paths: Vec<Path>,
    pub attributes: Vec<(String, AttrValue)>,
    /// 0 = even-odd, 1 = non-zero.
    pub fill_rule: u8,
}

#[derive(Debug, Clone, PartialEq, Default)]
pub struct Path {
    pub closed: bool,
    /// Optional 2×3 affine `[a, b, c, d, x, y]` (identity when absent).
    pub local_transform: Option<[f64; 6]>,
    pub segments: Vec<Segment>,
    pub attributes: Vec<(String, AttrValue)>,
}

/// A line (no controls) or cubic bezier between two point ids. Control
/// points are absolute positions.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Segment {
    pub a: u32,
    pub b: u32,
    pub ctrl1: Option<[f64; 2]>,
    pub ctrl2: Option<[f64; 2]>,
}

/// Where in time the evaluation is.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Context {
    /// Composition frame (fractional under motion blur).
    pub frame: f64,
    /// Seconds since the composition start.
    pub time: f64,
    pub fps: f64,
    /// Composition size in pixels. Geometry is in composition pixels with
    /// the origin at the comp centre, +y down.
    pub comp_width: f64,
    pub comp_height: f64,
    /// Frames since the layer's first frame.
    pub layer_frame: f64,
    /// Stable per-node seed in [0, 1).
    pub seed: f64,
}

#[derive(Debug, Clone, PartialEq, Default)]
pub struct Request {
    /// The `logic` export being called (one module can serve several nodes).
    pub node: String,
    pub context: Context,
    /// Non-image inputs that are connected, by port id.
    pub inputs: Vec<(String, Value)>,
    /// Every param, resolved at this frame (keyframes and wires applied).
    pub params: Vec<(String, Value)>,
}

#[derive(Debug, Clone, PartialEq, Default)]
pub struct Response {
    /// By output port id. A `params.<id>` key overrides that param for the
    /// node's GPU passes.
    pub outputs: Vec<(String, Value)>,
    /// Shown in Caddis' status console (deduplicated).
    pub logs: Vec<String>,
    /// Non-empty = the evaluation failed; the node outputs nothing.
    pub error: String,
}

// ── encoding ────────────────────────────────────────────────────────────

const TAG_NONE: u8 = 0;
const TAG_SCALAR: u8 = 1;
const TAG_VEC2: u8 = 2;
const TAG_VEC3: u8 = 3;
const TAG_COLOR: u8 = 4;
const TAG_BOOL: u8 = 5;
const TAG_STRING: u8 = 6;
const TAG_POINTS: u8 = 7;
const TAG_SHAPE: u8 = 8;
const TAG_DRAW: u8 = 9;
const TAG_FLOATS: u8 = 10;

struct W(Vec<u8>);

impl W {
    fn u8(&mut self, v: u8) {
        self.0.push(v);
    }
    fn u32(&mut self, v: u32) {
        self.0.extend_from_slice(&v.to_le_bytes());
    }
    fn f64(&mut self, v: f64) {
        self.0.extend_from_slice(&v.to_le_bytes());
    }
    fn fs<const N: usize>(&mut self, v: &[f64; N]) {
        for x in v {
            self.f64(*x);
        }
    }
    fn str(&mut self, s: &str) {
        self.u32(s.len() as u32);
        self.0.extend_from_slice(s.as_bytes());
    }
    fn points(&mut self, p: &Points) {
        self.u32(p.ids.len() as u32);
        for (id, pos) in p.ids.iter().zip(&p.positions) {
            self.u32(*id);
            self.fs(pos);
        }
        self.u32(p.next_id);
        self.u32(p.attributes.len() as u32);
        for (name, a) in &p.attributes {
            self.str(name);
            match a {
                Attr::Scalar(v) => {
                    self.u8(1);
                    self.u32(v.len() as u32);
                    v.iter().for_each(|x| self.f64(*x));
                }
                Attr::Vec2(v) => {
                    self.u8(2);
                    self.u32(v.len() as u32);
                    v.iter().for_each(|x| self.fs(x));
                }
                Attr::Vec3(v) => {
                    self.u8(3);
                    self.u32(v.len() as u32);
                    v.iter().for_each(|x| self.fs(x));
                }
                Attr::Vec4(v) => {
                    self.u8(4);
                    self.u32(v.len() as u32);
                    v.iter().for_each(|x| self.fs(x));
                }
            }
        }
    }
    fn attr_values(&mut self, attrs: &[(String, AttrValue)]) {
        self.u32(attrs.len() as u32);
        for (name, v) in attrs {
            self.str(name);
            match v {
                AttrValue::Scalar(x) => {
                    self.u8(1);
                    self.f64(*x);
                }
                AttrValue::Vec2(x) => {
                    self.u8(2);
                    self.fs(x);
                }
                AttrValue::Vec3(x) => {
                    self.u8(3);
                    self.fs(x);
                }
                AttrValue::Vec4(x) => {
                    self.u8(4);
                    self.fs(x);
                }
                AttrValue::String(s) => {
                    self.u8(5);
                    self.str(s);
                }
            }
        }
    }
    fn value(&mut self, v: &Value) {
        match v {
            Value::None => self.u8(TAG_NONE),
            Value::Scalar(x) => {
                self.u8(TAG_SCALAR);
                self.f64(*x);
            }
            Value::Vec2(x) => {
                self.u8(TAG_VEC2);
                self.fs(x);
            }
            Value::Vec3(x) => {
                self.u8(TAG_VEC3);
                self.fs(x);
            }
            Value::Color(x) => {
                self.u8(TAG_COLOR);
                self.fs(x);
            }
            Value::Bool(b) => {
                self.u8(TAG_BOOL);
                self.u8(*b as u8);
            }
            Value::String(s) => {
                self.u8(TAG_STRING);
                self.str(s);
            }
            Value::Points(p) => {
                self.u8(TAG_POINTS);
                self.points(p);
            }
            Value::Shape(s) => {
                self.u8(TAG_SHAPE);
                self.points(&s.points);
                self.u32(s.paths.len() as u32);
                for path in &s.paths {
                    self.u8(path.closed as u8);
                    match &path.local_transform {
                        Some(t) => {
                            self.u8(1);
                            self.fs(t);
                        }
                        None => self.u8(0),
                    }
                    self.u32(path.segments.len() as u32);
                    for seg in &path.segments {
                        self.u32(seg.a);
                        self.u32(seg.b);
                        let flags =
                            (seg.ctrl1.is_some() as u8) | ((seg.ctrl2.is_some() as u8) << 1);
                        self.u8(flags);
                        if let Some(c) = &seg.ctrl1 {
                            self.fs(c);
                        }
                        if let Some(c) = &seg.ctrl2 {
                            self.fs(c);
                        }
                    }
                    self.attr_values(&path.attributes);
                }
                self.attr_values(&s.attributes);
                self.u8(s.fill_rule);
            }
            Value::Draw(items) => {
                self.u8(TAG_DRAW);
                self.u32(items.len() as u32);
                items.iter().for_each(|d| self.draw_item(d));
            }
            Value::Floats(v) => {
                self.u8(TAG_FLOATS);
                self.u32(v.len() as u32);
                v.iter().for_each(|x| self.f64(*x));
            }
        }
    }
    fn paint(&mut self, p: &Paint) {
        self.u8(p.token as u8);
        self.f64(p.alpha);
        self.u8(p.fill as u8);
        self.f64(p.width);
    }
    fn draw_item(&mut self, d: &DrawItem) {
        match d {
            DrawItem::Rect {
                rect,
                radius,
                paint,
            } => {
                self.u8(1);
                self.fs(rect);
                self.f64(*radius);
                self.paint(paint);
            }
            DrawItem::Line { a, b, paint } => {
                self.u8(2);
                self.fs(a);
                self.fs(b);
                self.paint(paint);
            }
            DrawItem::Polyline {
                points,
                closed,
                paint,
            } => {
                self.u8(3);
                self.u32(points.len() as u32);
                points.iter().for_each(|p| self.fs(p));
                self.u8(*closed as u8);
                self.paint(paint);
            }
            DrawItem::Ellipse {
                center,
                radii,
                paint,
            } => {
                self.u8(4);
                self.fs(center);
                self.fs(radii);
                self.paint(paint);
            }
            DrawItem::Text {
                pos,
                text,
                size,
                align,
                paint,
            } => {
                self.u8(5);
                self.fs(pos);
                self.str(text);
                self.f64(*size);
                self.u8(*align as u8);
                self.paint(paint);
            }
            DrawItem::Handle { pos, radius, id } => {
                self.u8(6);
                self.fs(pos);
                self.f64(*radius);
                self.str(id);
            }
            DrawItem::Histogram { rect, channel } => {
                self.u8(9);
                self.fs(rect);
                self.u8(*channel as u8);
            }
            DrawItem::HandleArea { rect, id } => {
                self.u8(8);
                self.fs(rect);
                self.str(id);
            }
            // Its own tag, so modules built before styles still decode.
            DrawItem::StyledHandle {
                pos,
                radius,
                id,
                style,
            } => {
                self.u8(7);
                self.fs(pos);
                self.f64(*radius);
                self.str(id);
                self.u8(*style as u8);
            }
        }
    }
    fn pairs(&mut self, pairs: &[(String, Value)]) {
        self.u32(pairs.len() as u32);
        for (k, v) in pairs {
            self.str(k);
            self.value(v);
        }
    }
}

pub fn encode_request(r: &Request) -> Vec<u8> {
    let mut w = W(Vec::with_capacity(256));
    w.0.extend_from_slice(b"CPQ1");
    w.str(&r.node);
    let c = &r.context;
    for x in [
        c.frame,
        c.time,
        c.fps,
        c.comp_width,
        c.comp_height,
        c.layer_frame,
        c.seed,
    ] {
        w.f64(x);
    }
    w.pairs(&r.inputs);
    w.pairs(&r.params);
    w.0
}

pub fn encode_response(r: &Response) -> Vec<u8> {
    let mut w = W(Vec::with_capacity(256));
    w.0.extend_from_slice(b"CPR1");
    w.pairs(&r.outputs);
    w.u32(r.logs.len() as u32);
    for l in &r.logs {
        w.str(l);
    }
    w.str(&r.error);
    w.0
}

// ── decoding ────────────────────────────────────────────────────────────

/// Why a buffer couldn't be decoded.
#[derive(Debug, Clone, PartialEq)]
pub struct DecodeError(pub &'static str);

struct R<'a> {
    b: &'a [u8],
    at: usize,
}

type DR<T> = Result<T, DecodeError>;

impl<'a> R<'a> {
    fn take(&mut self, n: usize) -> DR<&'a [u8]> {
        if self.at + n > self.b.len() {
            return Err(DecodeError("truncated"));
        }
        let s = &self.b[self.at..self.at + n];
        self.at += n;
        Ok(s)
    }
    fn u8(&mut self) -> DR<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> DR<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn f64(&mut self) -> DR<f64> {
        Ok(f64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn fs<const N: usize>(&mut self) -> DR<[f64; N]> {
        let mut out = [0.0; N];
        for x in out.iter_mut() {
            *x = self.f64()?;
        }
        Ok(out)
    }
    /// A count that must fit in what's left (each item ≥ `min` bytes) — a
    /// corrupt length can't make us allocate gigabytes.
    fn count(&mut self, min: usize) -> DR<usize> {
        let n = self.u32()? as usize;
        if n.saturating_mul(min.max(1)) > self.b.len() - self.at {
            return Err(DecodeError("bad length"));
        }
        Ok(n)
    }
    fn str(&mut self) -> DR<String> {
        let n = self.count(1)?;
        let s = self.take(n)?;
        core::str::from_utf8(s)
            .map(String::from)
            .map_err(|_| DecodeError("bad utf-8"))
    }
    fn points(&mut self) -> DR<Points> {
        let n = self.count(20)?;
        let mut p = Points {
            ids: Vec::with_capacity(n),
            positions: Vec::with_capacity(n),
            ..Default::default()
        };
        for _ in 0..n {
            p.ids.push(self.u32()?);
            p.positions.push(self.fs()?);
        }
        p.next_id = self.u32()?;
        let na = self.count(5)?;
        for _ in 0..na {
            let name = self.str()?;
            let kind = self.u8()?;
            let len = self.count(8 * kind.max(1) as usize)?;
            let a = match kind {
                1 => Attr::Scalar((0..len).map(|_| self.f64()).collect::<DR<_>>()?),
                2 => Attr::Vec2((0..len).map(|_| self.fs()).collect::<DR<_>>()?),
                3 => Attr::Vec3((0..len).map(|_| self.fs()).collect::<DR<_>>()?),
                4 => Attr::Vec4((0..len).map(|_| self.fs()).collect::<DR<_>>()?),
                _ => return Err(DecodeError("bad attribute kind")),
            };
            p.attributes.push((name, a));
        }
        Ok(p)
    }
    fn attr_values(&mut self) -> DR<Vec<(String, AttrValue)>> {
        let n = self.count(6)?;
        let mut out = Vec::with_capacity(n);
        for _ in 0..n {
            let name = self.str()?;
            let v = match self.u8()? {
                1 => AttrValue::Scalar(self.f64()?),
                2 => AttrValue::Vec2(self.fs()?),
                3 => AttrValue::Vec3(self.fs()?),
                4 => AttrValue::Vec4(self.fs()?),
                5 => AttrValue::String(self.str()?),
                _ => return Err(DecodeError("bad attribute value")),
            };
            out.push((name, v));
        }
        Ok(out)
    }
    fn value(&mut self) -> DR<Value> {
        Ok(match self.u8()? {
            TAG_NONE => Value::None,
            TAG_SCALAR => Value::Scalar(self.f64()?),
            TAG_VEC2 => Value::Vec2(self.fs()?),
            TAG_VEC3 => Value::Vec3(self.fs()?),
            TAG_COLOR => Value::Color(self.fs()?),
            TAG_BOOL => Value::Bool(self.u8()? != 0),
            TAG_STRING => Value::String(self.str()?),
            TAG_POINTS => Value::Points(self.points()?),
            TAG_SHAPE => {
                let points = self.points()?;
                let np = self.count(10)?;
                let mut paths = Vec::with_capacity(np);
                for _ in 0..np {
                    let closed = self.u8()? != 0;
                    let local_transform = if self.u8()? == 1 {
                        Some(self.fs()?)
                    } else {
                        None
                    };
                    let ns = self.count(9)?;
                    let mut segments = Vec::with_capacity(ns);
                    for _ in 0..ns {
                        let a = self.u32()?;
                        let b = self.u32()?;
                        let flags = self.u8()?;
                        let ctrl1 = if flags & 1 != 0 {
                            Some(self.fs()?)
                        } else {
                            None
                        };
                        let ctrl2 = if flags & 2 != 0 {
                            Some(self.fs()?)
                        } else {
                            None
                        };
                        segments.push(Segment { a, b, ctrl1, ctrl2 });
                    }
                    let attributes = self.attr_values()?;
                    paths.push(Path {
                        closed,
                        local_transform,
                        segments,
                        attributes,
                    });
                }
                let attributes = self.attr_values()?;
                let fill_rule = self.u8()?;
                Value::Shape(Shape {
                    points,
                    paths,
                    attributes,
                    fill_rule,
                })
            }
            TAG_DRAW => {
                let n = self.count(10)?;
                Value::Draw((0..n).map(|_| self.draw_item()).collect::<DR<_>>()?)
            }
            TAG_FLOATS => {
                let n = self.count(8)?;
                Value::Floats((0..n).map(|_| self.f64()).collect::<DR<_>>()?)
            }
            _ => return Err(DecodeError("bad value tag")),
        })
    }
    fn paint(&mut self) -> DR<Paint> {
        let token = Token::from_u8(self.u8()?).ok_or(DecodeError("bad colour token"))?;
        Ok(Paint {
            token,
            alpha: self.f64()?,
            fill: self.u8()? != 0,
            width: self.f64()?,
        })
    }
    fn draw_item(&mut self) -> DR<DrawItem> {
        Ok(match self.u8()? {
            1 => DrawItem::Rect {
                rect: self.fs()?,
                radius: self.f64()?,
                paint: self.paint()?,
            },
            2 => DrawItem::Line {
                a: self.fs()?,
                b: self.fs()?,
                paint: self.paint()?,
            },
            3 => {
                let n = self.count(16)?;
                let points = (0..n).map(|_| self.fs()).collect::<DR<_>>()?;
                DrawItem::Polyline {
                    points,
                    closed: self.u8()? != 0,
                    paint: self.paint()?,
                }
            }
            4 => DrawItem::Ellipse {
                center: self.fs()?,
                radii: self.fs()?,
                paint: self.paint()?,
            },
            5 => DrawItem::Text {
                pos: self.fs()?,
                text: self.str()?,
                size: self.f64()?,
                align: Align::from_u8(self.u8()?).ok_or(DecodeError("bad text align"))?,
                paint: self.paint()?,
            },
            6 => DrawItem::Handle {
                pos: self.fs()?,
                radius: self.f64()?,
                id: self.str()?,
            },
            9 => DrawItem::Histogram {
                rect: self.fs()?,
                channel: HistogramChannel::from_u8(self.u8()?)
                    .ok_or(DecodeError("bad histogram channel"))?,
            },
            8 => DrawItem::HandleArea {
                rect: self.fs()?,
                id: self.str()?,
            },
            7 => DrawItem::StyledHandle {
                pos: self.fs()?,
                radius: self.f64()?,
                id: self.str()?,
                style: HandleStyle::from_u8(self.u8()?).ok_or(DecodeError("bad handle style"))?,
            },
            _ => return Err(DecodeError("bad draw item")),
        })
    }
    fn pairs(&mut self) -> DR<Vec<(String, Value)>> {
        let n = self.count(5)?;
        let mut out = Vec::with_capacity(n);
        for _ in 0..n {
            out.push((self.str()?, self.value()?));
        }
        Ok(out)
    }
}

pub fn decode_request(b: &[u8]) -> Result<Request, DecodeError> {
    let mut r = R { b, at: 0 };
    if r.take(4)? != b"CPQ1" {
        return Err(DecodeError("not a Caddis request (wrong SDK version?)"));
    }
    let node = r.str()?;
    let f: [f64; 7] = r.fs()?;
    let context = Context {
        frame: f[0],
        time: f[1],
        fps: f[2],
        comp_width: f[3],
        comp_height: f[4],
        layer_frame: f[5],
        seed: f[6],
    };
    Ok(Request {
        node,
        context,
        inputs: r.pairs()?,
        params: r.pairs()?,
    })
}

pub fn decode_response(b: &[u8]) -> Result<Response, DecodeError> {
    let mut r = R { b, at: 0 };
    if r.take(4)? != b"CPR1" {
        return Err(DecodeError("not a Caddis response (wrong SDK version?)"));
    }
    let outputs = r.pairs()?;
    let nl = r.count(4)?;
    let logs = (0..nl).map(|_| r.str()).collect::<DR<_>>()?;
    let error = r.str()?;
    Ok(Response {
        outputs,
        logs,
        error,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloc::vec;

    fn sample_shape() -> Shape {
        Shape {
            points: Points {
                ids: vec![0, 1, 2],
                positions: vec![[0.0, 0.0], [10.0, 0.0], [5.0, 8.0]],
                next_id: 3,
                attributes: vec![("scale".into(), Attr::Scalar(vec![1.0, 2.0, 3.0]))],
            },
            paths: vec![Path {
                closed: true,
                local_transform: Some([1.0, 0.0, 0.0, 1.0, 4.0, 5.0]),
                segments: vec![
                    Segment {
                        a: 0,
                        b: 1,
                        ctrl1: None,
                        ctrl2: None,
                    },
                    Segment {
                        a: 1,
                        b: 2,
                        ctrl1: Some([12.0, 4.0]),
                        ctrl2: Some([8.0, 9.0]),
                    },
                ],
                attributes: vec![("color".into(), AttrValue::Vec4([1.0, 0.0, 0.0, 1.0]))],
            }],
            attributes: vec![("name".into(), AttrValue::String("tri".into()))],
            fill_rule: 1,
        }
    }

    #[test]
    fn request_round_trips() {
        let r = Request {
            node: "jitter".into(),
            context: Context {
                frame: 12.5,
                fps: 30.0,
                seed: 0.25,
                ..Default::default()
            },
            inputs: vec![("shape".into(), Value::Shape(sample_shape()))],
            params: vec![
                ("amount".into(), Value::Scalar(3.0)),
                ("mode".into(), Value::String("Soft".into())),
                ("on".into(), Value::Bool(true)),
                ("tint".into(), Value::Color([1.0, 0.5, 0.0, 1.0])),
            ],
        };
        assert_eq!(decode_request(&encode_request(&r)).unwrap(), r);
    }

    #[test]
    fn response_round_trips() {
        let r = Response {
            outputs: vec![("out".into(), Value::Points(sample_shape().points))],
            logs: vec!["hello".into()],
            error: String::new(),
        };
        assert_eq!(decode_response(&encode_response(&r)).unwrap(), r);
    }

    #[test]
    fn garbage_is_rejected_not_trusted() {
        assert!(decode_request(b"nope").is_err());
        let mut bytes = encode_request(&Request::default());
        bytes.truncate(bytes.len() - 2);
        assert!(decode_request(&bytes).is_err());
        // A huge declared count can't allocate.
        let mut evil = b"CPR1".to_vec();
        evil.extend_from_slice(&u32::MAX.to_le_bytes());
        assert_eq!(decode_response(&evil), Err(DecodeError("bad length")));
    }

    #[test]
    fn draw_lists_and_floats_round_trip() {
        use crate::ui::DrawList;
        let mut d = DrawList::new();
        d.rect([0.0, 0.0, 100.0, 40.0], 2.0, Paint::fill(Token::Inset))
            .polyline(
                &[[0.0, 40.0], [50.0, 0.0], [100.0, 40.0]],
                false,
                Paint::stroke(Token::Accent, 1.5).alpha(0.5),
            )
            .text(
                [50.0, 20.0],
                "Glow",
                9.0,
                Align::Center,
                Paint::fill(Token::Muted),
            )
            .handle([50.0, 0.0], 5.0, "peak");
        let r = Response {
            outputs: alloc::vec![
                ("@draw".into(), Value::Draw(d.0.clone())),
                (
                    "@lut".into(),
                    Value::Floats(alloc::vec![0.0, 0.25, 0.5, 1.0])
                ),
            ],
            ..Default::default()
        };
        let back = decode_response(&encode_response(&r)).unwrap();
        assert_eq!(back, r);
    }
}
