# Caddis Plugin Kit

Everything you need to make Caddis plugins: nodes that live in the node graph next to the built-in ones, written as GLSL or WGSL shaders, with optional CPU logic in WebAssembly.

```
Caddis Plugin Kit/
├── START HERE.md        this page
├── docs/                the SDK guide (also at docs.caddis.app/sdk)
├── examples/
│   ├── glsl-starter/    copy this: five GLSL nodes — one pass, a reusable blur module,
│   │                    a bundled texture, GPU buffers with atomics, viewer handles
│   ├── datamosh/        a stateful, multi-pass effect that reads the previous frame
│   ├── point-tools/     WebAssembly logic: points, shapes, a particle system
│   └── custom-ui/       a control and a viewer handle the plugin draws itself
└── rust/caddis-plugin/  the Rust crate for WebAssembly logic (only needed for CPU code)
```

## Your first plugin in ten minutes

You need a Caddis build with plugin support. The tool that checks and packs plugins comes inside it.

**1. Try the example.** In Caddis, open **Plugins › Manage Plugins…**, choose **Developer › Add Development Folder…**, and pick `examples/glsl-starter`. Right-click the node graph and open the **Plugins** category: **Duotone**, **Soft Glow**, **Ordered Dither**, **Histogram** and **Spotlight** are there. Put one between an image and the Output.

**2. Edit it live.** Open `examples/glsl-starter/shaders/duotone.glsl`, change something and save. Caddis reloads the plugin and re-renders. If a shader doesn't compile, Manage Plugins shows the file, line and column.

**3. Make your own.** Copy the `glsl-starter` folder, change `id` in `plugin.json` to your own reverse-DNS name (`com.yourname.whatever`), and replace the nodes with yours. [docs/porting.md](docs/porting.md) is the checklist for bringing an existing shader across: what to remove, how coordinates, alpha and uniforms map, and a before/after.

**4. Pack it.** In Terminal:

```sh
CADDIS=/Applications/Caddis.app/Contents/Resources/cadmium-engine
$CADDIS plugin check ./my-plugin
$CADDIS plugin pack ./my-plugin -o my-plugin.cadplugin
```

Add `--protect` to `pack` to encrypt your shaders so they can't be read out of the file. Anyone installs the `.cadplugin` by double-clicking it.

**5. Sell it (optional).** Caddis checks licence keys from Gumroad, Lemon Squeezy and Keygen, or offline keys you sign yourself, and gives unlicensed copies a trial watermark. See [docs/selling.md](docs/selling.md).

## Read next

| | |
|---|---|
| [docs/index.md](docs/index.md) | What a plugin is, and the plugin tool |
| [docs/porting.md](docs/porting.md) | Bringing GLSL across from Shadertoy, After Effects, OFX or TouchDesigner |
| [docs/manifest.md](docs/manifest.md) | Every field of `plugin.json` |
| [docs/shaders.md](docs/shaders.md) | The shader contract: built-in values, compute passes, point buffers |
| [docs/time-and-state.md](docs/time-and-state.md) | Reading other frames, feedback, triggers |
| [docs/logic.md](docs/logic.md) | CPU code in Rust / WebAssembly |
| [docs/selling.md](docs/selling.md) | Protection, licence keys, trials |
| [docs/plugins-in-caddis.md](docs/plugins-in-caddis.md) | How users install and manage plugins |

Found something that doesn't convert, or a feature you need? Tell us. The SDK is new and your reports shape it.
