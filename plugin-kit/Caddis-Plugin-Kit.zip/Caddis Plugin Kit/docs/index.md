# Plugin SDK

Make your own Caddis nodes and share or sell them as `.cadplugin` files.

A plugin is a folder of plain files, zipped:

```
glow-pack/
├── plugin.json        what the plugin's nodes are: ports, settings, passes
├── shaders/*.wgsl     GPU code — WGSL, or GLSL
├── logic.wasm         optional CPU code (points, shapes, values), WebAssembly
├── docs/<node>.md     optional help page per node
└── icon.png           optional icon for Manage Plugins
```

Plugin nodes are real Caddis nodes. Their settings render in Properties with the same controls as built-in nodes, keyframe, can be exposed as input ports, and are cached, scrubbed, motion-blurred and exported like everything else. Caddis runs everything on the plugin's behalf: it compiles the shaders, allocates every texture, schedules the passes and calls the WebAssembly. A plugin never touches the GPU API, the file system, the network or the clock. That's what makes one `.cadplugin` work on macOS, Windows and Linux, on any GPU, without being able to crash Caddis.

## Hello, node

`plugin.json`:

```json
{
  "sdk": 1,
  "id": "com.example.tint",
  "name": "Tint",
  "version": "1.0.0",
  "vendor": "Example Studio",
  "nodes": [
    {
      "id": "tint",
      "label": "Tint",
      "inputs": [{ "id": "src", "type": "image", "label": "Source" }],
      "outputs": [{ "id": "out", "type": "image" }],
      "params": [
        { "id": "color", "type": "color", "default": [1, 0.5, 0.2, 1] },
        { "id": "amount", "type": "float", "default": 1, "min": 0, "max": 1, "expose": true }
      ],
      "passes": [{ "shader": "tint.wgsl", "reads": ["src"], "writes": "out" }]
    }
  ]
}
```

`tint.wgsl`:

```wgsl
fn shade(uv: vec2<f32>) -> vec4<f32> {
  let c = textureSample(src, samp, uv);
  return vec4<f32>(mix(c.rgb, c.rgb * params.color.rgb, params.amount), c.a);
}
```

Or the same thing in GLSL (`tint.glsl`, with the pass pointing at it):

```glsl
vec4 shade(vec2 uv) {
    vec4 c = texture(src, uv);
    return vec4(mix(c.rgb, c.rgb * color.rgb, amount), c.a);
}
```

## Develop with live reload

1. In Caddis, open **Plugins › Manage Plugins… › Developer › Add Development Folder…** and pick your plugin folder.
2. Edit and save. Caddis reloads the plugin and re-renders. Problems show in Manage Plugins with the file, line and column.

## Check and package

Every Caddis install includes the plugin tool. It's the engine binary with a `plugin` command:

```sh
# macOS
/Applications/Caddis.app/Contents/Resources/cadmium-engine plugin check ./glow-pack
/Applications/Caddis.app/Contents/Resources/cadmium-engine plugin pack ./glow-pack -o glow-pack.cadplugin
```

On Windows the binary is `cadmium-engine.exe` in the Caddis install's `resources` folder.

`pack` refuses to build a plugin that doesn't load. Add `--protect` to encrypt your shaders and WebAssembly (see [Selling Plugins](selling.md)).

## Compatibility

Every manifest starts with `"sdk": 1`, the version of this interface it was written for. A plugin you ship keeps working as Caddis updates:

- **New features are additions.** New setting types, drawing commands and manifest fields are added alongside the old ones, so a plugin built today keeps loading, rendering and drawing its controls unchanged. Rebuild with a newer SDK only to use something new.
- **Caddis's look is Caddis's.** Plugins name roles (color tokens, handle styles, "a histogram here"), and Caddis draws them. When Caddis's look changes, your controls follow with no update.
- **A change that can't be an addition gets a new SDK version.** Plugins declaring the old version keep the old behavior.

## Where to go next

- [Manifest Reference](manifest.md) — nodes, ports, settings, textures, passes, bounds
- [Writing Shaders](shaders.md) — the WGSL / GLSL contract, compute passes, point buffers
- [Porting Shaders](porting.md) — bringing GLSL from Shadertoy, After Effects, OFX or TouchDesigner
- [Time and State](time-and-state.md) — reading other frames, feedback, triggers
- [CPU Logic](logic.md) — points, shapes and values in Rust / WebAssembly
- [Selling Plugins](selling.md) — protection, license keys, trials

Example plugins (a GLSL starter, datamosh, point tools, custom UI) are in the Plugin Kit's `examples/` folder.
