# Selling Plugins

Sell your plugins wherever you already sell: your own site, Gumroad, Lemon Squeezy, aescripts or anywhere else that hands out license keys. Caddis doesn't take a cut, process payments or run a store. It protects your files and checks the keys your store issues, so you don't have to build anything just for Caddis.

## Protecting your source

```sh
cadmium-engine plugin pack ./my-plugin -o my-plugin.cadplugin --protect
```

`--protect` encrypts every shader and the WebAssembly module inside the `.cadplugin`. Caddis decrypts them only in memory while rendering. They're never written to disk and never shown in the app. A protected bundle can't be opened with a zip tool and read, and changing any byte breaks it.

To be straight about it: this is the same bar as After Effects plugins. Anything a GPU has to run can, in the end, be recovered by someone determined with a debugger. Protection keeps your code from being casually read or copied, and that's what it's for.

## Licenses

Add a `license` block to `plugin.json`:

```json
"license": {
  "provider": "gumroad",
  "product": "your-product-id",
  "trial": true,
  "purchaseUrl": "https://you.gumroad.com/l/glowpack"
}
```

| Field | |
|---|---|
| `provider` | Where keys come from (below). |
| `product` | Store product id (Gumroad product id, Lemon Squeezy product id, Keygen account id). |
| `publicKey` | `signed` and `https` providers: your public key from `plugin keygen`. |
| `activationUrl` | `https` provider: your activation endpoint. |
| `trial` | `true` (default): unlicensed copies render with a Caddis watermark. `false`: they render nothing. |
| `recheckDays` | How often store keys are re-checked online (default 30). Offline users keep their license for one extra period. |
| `purchaseUrl` | Where the **Buy** button in Manage Plugins goes. |

Users paste their key into **Plugins › Manage Plugins…** and choose **Activate**.

### Providers

**`gumroad`, `lemonsqueezy`, `keygen`** — Caddis checks the key with the store's own license API, the same one any app uses. Sell as you normally would, and the store's standard license key works.

**`signed`** — Offline keys you mint yourself, with nothing online. Make a key pair once:

```sh
cadmium-engine plugin keygen
```

Put the **public** key in `license.publicKey`. Keep the **secret** key private. Then mint a key per sale, by hand or from your store's webhook:

```sh
cadmium-engine plugin sign-license --secret <secret key> --plugin com.you.glowpack \
  --licensee "Buyer Name" [--email buyer@example.com] [--expires 2027-12-31] [--machine <id>]
```

Keys are signed (Ed25519), so nobody can mint them without your secret key. `--expires` makes a time-limited license. `plugin verify-license` checks one.

**`https`** — Your own license server. When a user activates, Caddis POSTs JSON `{ licenseKey, pluginId, pluginVersion, machineId, machineName }` to `activationUrl`. Answer with `{ "token": "<signed key>" }`: a key you minted for that buyer, optionally bound to `machineId`. Or answer with `{ "error": "message to show" }`. Caddis then verifies the token offline with your `publicKey`.

### Trials

With `"trial": true`, an unlicensed copy works fully, but Caddis draws diagonal stripes over the node's image outputs (in the viewer and in exports) and the node shows a **TRIAL** pill. The watermark is drawn by Caddis, so every plugin's trial behaves the same, and a plugin can't remove it. Points and shapes your logic outputs are not watermarked. If that matters to you, use `"trial": false`.

## Distributing

A `.cadplugin` is one file, so sell it as a download. Users install it by double-clicking it, dragging it onto Caddis, or using **Plugins › Install Plugin…**. Vendor installers can place it in the machine-wide Plugins folder (see [Plugins](plugins-in-caddis.md)).

Before you release:

```sh
cadmium-engine plugin check my-plugin.cadplugin
```
