# Plugins

Plugins add new nodes to Caddis. A plugin is a single **`.cadplugin`** file. Once it's installed, its nodes appear in the node graph's **Plugins** menu category and behave like built-in nodes: their settings show in Properties, they keyframe, they can be driven by wires (the **E** button), and they render in previews and exports.

## Installing a plugin

Any of these installs a plugin:

- **Plugins › Install Plugin…** — pick one or more `.cadplugin` files.
- **Double-click** a `.cadplugin` file — Caddis asks before installing.
- **Drag** a `.cadplugin` file onto the Caddis window.
- **Drop it into the Plugins folder** yourself — **Plugins › Reveal Plugins Folder** opens it. Caddis notices new files while it's running; no restart needed.

The Plugins folder lives with your other Caddis settings, not inside the app, so plugins survive updates:

| | Folder |
|---|---|
| macOS | `~/Library/Application Support/Caddis/Plugins` |
| Windows | `%APPDATA%\Caddis\Plugins` |
| Linux | `~/.config/Caddis/Plugins` |

A studio can install a plugin for everyone on a machine by placing it in `/Library/Application Support/Caddis/Plugins` (macOS), `C:\ProgramData\Caddis\Plugins` (Windows) or `/usr/share/caddis/plugins` (Linux).

Installing a newer version of a plugin replaces the old one.

## Using plugin nodes

Right-click the node graph (or press Tab) and open the **Plugins** category, or just search — search finds plugin nodes by their own name, the plugin's name and the vendor's name.

Plugin nodes have an **orchid border** and a small pill above the node naming the vendor, so you can always tell them from built-in nodes. Selecting a node keeps the pill. Hover the pill for the plugin's name and version. The **?** button in Properties opens the plugin's own help page.

Some plugins have **point** settings (a position in the frame). With the node selected, those show as draggable handles in the viewer.

## Managing plugins

**Plugins › Manage Plugins…** lists every plugin Caddis found. A row only shows a status when something needs your attention: **Off**, **Trial**, **Needs license**, **Failed to load** or **Duplicate**. A healthy plugin shows nothing extra.

- **On** switches a plugin on or off. A switched-off plugin stays installed, but its nodes don't render.
- If a plugin has problems, click **details** under it to see them, with the file and line, which is useful when reporting a bug to its author.
- A paid plugin on trial shows its **license** line (below).
- **⋯** on each row: **Show in Finder**, **Copy Plugin Details** (everything a plugin's author needs for a bug report), **Remove License Key**, and **Uninstall…** (or **Remove Folder** for a development folder).

**Developer** at the bottom holds the tools for making plugins: **Add Development Folder…** (a folder Caddis reloads live as you edit), **Reload Plugins** and **Reveal Plugins Folder**.

## Paid plugins and licenses

A paid plugin may run as a **trial** before you buy it: it works normally but Caddis draws diagonal stripes over its output, and its nodes show a **TRIAL** pill. Some paid plugins don't offer a trial — those render nothing until licensed and show **UNLICENSED**.

To license a plugin, open **Plugins › Manage Plugins…**, paste the key you received from the seller into the plugin's **License key** field and choose **Activate**. **Buy** opens the seller's page when the plugin provides one. Most keys are checked once online and then periodically; being offline for a while doesn't switch a licensed plugin back to trial.

License keys are stored encrypted on your computer and are never shared with Caddis.

## When a project uses a plugin you don't have

If you open a project that uses a plugin that isn't installed (or is switched off), its nodes keep all their settings and keyframes, show a dashed amber border with a **MISSING** pill, and render nothing. Hover the pill to see which plugin and version it needs. Install the plugin and the nodes come back exactly as they were.

## Making plugins

See the [Plugin SDK](index.md).
