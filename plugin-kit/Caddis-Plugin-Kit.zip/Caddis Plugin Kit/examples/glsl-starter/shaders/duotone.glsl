// Duotone — brightness mapped between two colours.
//
// No #version, uniforms or main(): Caddis writes those. Params are plain
// names (shadows, highlights, contrast, amount), and `src` is the Source
// input, read with texture() as usual. Colours are linear light with
// straight (unpremultiplied) alpha, coming in and going out.
vec4 shade(vec2 uv) {
    vec4 c = texture(src, uv);
    float luma = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));
    float t = clamp((luma - 0.5) * contrast + 0.5, 0.0, 1.0);
    vec3 duo = mix(shadows.rgb, highlights.rgb, t);
    return vec4(mix(c.rgb, duo, amount), c.a);
}
