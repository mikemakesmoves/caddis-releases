// Spotlight — viewer handles bound to params.
//
// plugin.json's "gizmos" draws a circle around `center` whose rim drags
// `radius`. `center` is a point param: composition pixels from the comp
// centre, +y down — caddis_to_uv() turns it into this canvas's uv.
vec4 shade(vec2 uv) {
    vec4 c = texture(src, uv);
    // Distance in comp px (uv * iResolution is comp px at every quality).
    float d = distance(uv * iResolution, caddis_to_uv(center) * iResolution);
    float edge = max(radius * feather, 1.0);
    float lit = 1.0 - smoothstep(radius - edge, radius, d);
    return vec4(c.rgb * mix(1.0 - darkness, 1.0, lit), c.a);
}
