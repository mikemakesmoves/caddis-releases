// Soft Glow, step 1: keep only the bright parts.
//
// Writes into `bright`, a half-resolution texture declared in plugin.json.
// Intermediate textures hold whatever you put in them; this one holds
// PREMULTIPLIED colour so the blur passes can average it without dark fringes.
vec4 shade(vec2 uv) {
    vec4 c = texture(src, uv);
    float luma = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));
    float k = smoothstep(threshold, threshold + softness, luma) * c.a;
    return vec4(c.rgb * k, k);
}
