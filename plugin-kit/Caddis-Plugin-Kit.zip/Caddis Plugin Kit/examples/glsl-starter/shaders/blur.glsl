// The `gaussian` module's shader: one Gaussian blur, run twice.
//
// The module in plugin.json runs this file once with AXIS = 0 (across) and
// once with AXIS = 1 (down) through "defines", and names whichever texture it
// reads `img` with "as". `radius` is the MODULE's param — each call binds it
// (Soft Glow passes "params.radius"), so any node can reuse this blur.
//
// Distances are in composition pixels: `uv * iResolution` is comp px at every
// quality level, so dividing a comp-px distance by iResolution gives the same
// blur at Draft, Preview and Full.
const int TAPS = 16;

vec4 shade(vec2 uv) {
    vec2 dir = AXIS == 0 ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
    vec2 reach = dir * radius / iResolution;
    vec4 sum = vec4(0.0);
    float total = 0.0;
    for (int i = -TAPS; i <= TAPS; i++) {
        float t = float(i) / float(TAPS);       // -1 .. 1 across the radius
        float w = exp(-4.5 * t * t);            // sigma = radius / 3
        sum += texture(img, uv + reach * t) * w;
        total += w;
    }
    return sum / total;
}
