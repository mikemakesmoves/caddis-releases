// Histogram, pass 1 of 3: count every texel's brightness into 256 bins.
//
// A compute pass that writes only a buffer runs once per texel of its first
// texture read (`src`). `bins` is declared "atomic", so many texels can add to
// the same bin at once — ordinary GLSL atomicAdd.
#include "lib/color.glsl"

void kernel(ivec2 p) {
    vec4 c = texelFetch(src, p, 0);
    if (c.a <= 0.0) { return; }
    uint bin = uint(clamp(luma(c.rgb), 0.0, 1.0) * 255.0);
    atomicAdd(bins_items[bin], 1u);
}
