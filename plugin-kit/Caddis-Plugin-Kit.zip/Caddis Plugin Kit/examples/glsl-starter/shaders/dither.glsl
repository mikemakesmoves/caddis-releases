// Ordered Dither — a bundled texture in action.
//
// `bayer` is the 8×8 matrix in textures/bayer8.png, declared under "assets"
// with filter nearest, wrap repeat and colorSpace data (its values are
// thresholds, not colours). Reading it is ordinary texture() — the asset's
// own sampler (repeat, nearest) is applied for you.
#include "lib/color.glsl"

vec4 shade(vec2 uv) {
    vec4 c = texture(src, uv);
    // One matrix tile per 8 cells; uv * iResolution is comp px at every quality.
    vec2 tile = uv * iResolution / (8.0 * cell);
    float threshold = texture(bayer, tile).r;
    float steps = float(levels - 1);
    vec3 q = floor(toDisplay(c.rgb) * steps + threshold) / steps;
    return vec4(fromDisplay(q), c.a);
}
