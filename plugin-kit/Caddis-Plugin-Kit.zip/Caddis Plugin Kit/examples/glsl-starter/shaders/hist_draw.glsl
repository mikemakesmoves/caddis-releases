// Histogram, pass 3 of 3: the source with the bars drawn along the bottom.
//
// Fragment passes read buffers as plain values (bins_items[i]).
vec4 shade(vec2 uv) {
    vec4 c = texture(src, uv);
    float fromBottom = 1.0 - uv.y;
    if (fromBottom > height) { return c; }
    uint bin = uint(clamp(uv.x, 0.0, 0.9999) * 256.0);
    float bar = float(bins_items[bin]) / max(float(peak_items[0]), 1.0);
    if (fromBottom / height > bar) { return c; }
    // Straight alpha: blend the bar colour over the source.
    float a = color.a;
    vec3 rgb = mix(c.rgb * c.a, color.rgb, a);
    float outA = a + c.a * (1.0 - a);
    return vec4(outA > 0.0 ? rgb / outA : vec3(0.0), outA);
}
