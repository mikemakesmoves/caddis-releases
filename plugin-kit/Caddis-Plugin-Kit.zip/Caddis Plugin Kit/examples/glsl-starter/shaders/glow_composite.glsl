// Soft Glow, last step: add the blurred glow back over the source.
//
// `glow` is the premultiplied blur (renamed from `bright` with "as"). The
// node's output must be STRAIGHT alpha, so work premultiplied and divide at
// the end. Bools arrive as an int: 0 or 1.
vec4 shade(vec2 uv) {
    vec4 c = texture(src, uv);
    vec4 g = texture(glow, uv) * intensity;
    g.rgb *= tint.rgb;

    vec3 base = glowOnly == 1 ? vec3(0.0) : c.rgb * c.a;
    float baseA = glowOnly == 1 ? 0.0 : c.a;

    vec3 premul = base + g.rgb;
    float a = clamp(baseA + g.a * (1.0 - baseA), 0.0, 1.0);
    return a > 0.0 ? vec4(premul / a, a) : vec4(0.0);
}
