// Shared helpers — pulled into any pass with #include "lib/color.glsl".
// Each file is included once per pass, however many times it's asked for.

float luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// Caddis images are linear light. Some looks (posterising, dithering) are
// tuned for display gamma, so convert around just that step.
vec3 toDisplay(vec3 c) { return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2)); }
vec3 fromDisplay(vec3 c) { return pow(max(c, vec3(0.0)), vec3(2.2)); }
