// Histogram, pass 2 of 3: the tallest bin, so the bars can be scaled to it.
//
// "dispatch": { "count": "256" } runs kernel_index once per bin.
void kernel_index(int i) {
    atomicMax(peak_items[0], bins_items[i]);
}
