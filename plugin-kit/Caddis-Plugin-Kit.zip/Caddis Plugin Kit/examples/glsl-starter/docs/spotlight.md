# Spotlight

> Darkens everything outside a circle.

Select the node and drag the circle in the viewer: the centre handle moves it, the handle on its rim sets the radius.

| Param | What it does |
|---|---|
| **Center** | Middle of the lit circle. |
| **Radius** | Size of the lit circle, in pixels. |
| **Feather** | How soft the edge is, as a share of the radius. |
| **Darkness** | How dark it gets outside. |
