# Soft Glow

> Blooms the bright parts of an image.

The bright areas are picked out, blurred at half resolution and added back on top. The glow can spread past the edges of the source by up to one and a half times the Radius.

| Param | What it does |
|---|---|
| **Threshold** | Brightness where the glow starts. |
| **Softness** | How gradually the glow fades in above the threshold. |
| **Radius** | How far the glow spreads, in pixels. |
| **Intensity** | How strong the glow is. Above 1 blows out. |
| **Tint** | Colours the glow. |
| **Glow Only** | Shows the glow without the source underneath. |
