# Duotone

> Maps an image's brightness between a shadow colour and a highlight colour.

| Param | What it does |
|---|---|
| **Shadows** | Colour for the darkest parts. |
| **Highlights** | Colour for the brightest parts. |
| **Contrast** | Pushes the image toward the two colours (1 = as is). |
| **Amount** | Blends between the original and the duotone. |
