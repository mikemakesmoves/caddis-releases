# Ordered Dither

> Reduces each channel to a few levels with an 8×8 Bayer pattern.

| Param | What it does |
|---|---|
| **Levels** | How many values each channel keeps (2 = pure on/off). |
| **Cell Size** | Size of one dither cell, in pixels. |
