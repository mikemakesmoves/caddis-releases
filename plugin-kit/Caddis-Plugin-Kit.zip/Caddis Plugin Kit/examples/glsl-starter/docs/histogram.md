# Histogram

> Draws the image's brightness histogram along the bottom of the frame.

| Param | What it does |
|---|---|
| **Height** | How much of the frame the bars may fill. |
| **Color** | Bar colour; its alpha is the bars' opacity. |
