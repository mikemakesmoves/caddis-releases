// The P-frame step. Motion is read per BLOCK (quantised to blockSize, the
// macroblock look), the previous mosh is pulled along it, and a share of
// the frame's real change (the residual) is painted on top.
fn shade(uv: vec2<f32>) -> vec4<f32> {
  let current = textureSample(src, samp, uv);
  // Clean frame: on a Clean Frame key, and on the layer's first frame.
  if (params.clean == 0.0 || builtins.iLayerFrame < 0.5) {
    return current;
  }
  let canvasPx = builtins.iTarget;
  let block = max(1.0, f32(params.blockSize) * builtins.iScale);
  let blockCenter = (floor(uv * canvasPx / block) + 0.5) * block / canvasPx;
  let mv = textureSampleLevel(flow, samp_point, blockCenter, 0.0).xy * params.motion;
  let origin = uv - mv / canvasPx;
  let moshed = textureSample(mosh, samp, origin);
  let before = textureSample(previous, samp, origin);
  let residual = (current - before) * params.residual;
  let p = clamp(moshed + residual, vec4<f32>(0.0), vec4<f32>(64.0));
  return mix(p, current, params.bleed);
}
