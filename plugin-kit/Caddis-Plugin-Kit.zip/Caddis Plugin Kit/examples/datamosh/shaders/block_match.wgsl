// Block matching: for each flow texel, find the offset into the PREVIOUS
// frame whose neighbourhood best matches this frame's (sum of absolute
// differences over a 4x4 sample grid). Output: motion in render pixels,
// pointing from where the content WAS to where it IS.
fn luma(c: vec4<f32>) -> f32 {
  return dot(c.rgb * c.a, vec3<f32>(0.2126, 0.7152, 0.0722));
}

fn shade(uv: vec2<f32>) -> vec4<f32> {
  let srcSize = vec2<f32>(textureDimensions(src));
  let px = 1.0 / srcSize;
  let range = f32(params.search) * builtins.iScale;
  let stride = max(1.0, range / 6.0);
  var best = 1e9;
  var bestOffset = vec2<f32>(0.0);
  for (var oy = -6; oy <= 6; oy = oy + 1) {
    for (var ox = -6; ox <= 6; ox = ox + 1) {
      let off = vec2<f32>(f32(ox), f32(oy)) * stride;
      var sad = 0.0;
      for (var sy = 0; sy < 4; sy = sy + 1) {
        for (var sx = 0; sx < 4; sx = sx + 1) {
          let s = (vec2<f32>(f32(sx), f32(sy)) - 1.5) * 2.0 * px * builtins.iScale * 2.0;
          let a = luma(textureSampleLevel(src, samp, uv + s, 0.0));
          let b = luma(textureSampleLevel(previous, samp, uv + s - off * px, 0.0));
          sad = sad + abs(a - b);
        }
      }
      // Prefer small motion on ties (still areas stay still).
      sad = sad + length(off) * 0.0005;
      if (sad < best) {
        best = sad;
        bestOffset = off;
      }
    }
  }
  return vec4<f32>(bestOffset, best, 1.0);
}
