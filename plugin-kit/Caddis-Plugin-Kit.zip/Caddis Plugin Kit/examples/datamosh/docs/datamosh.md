# Datamosh

> Codec-style datamoshing: the footage's own motion keeps dragging old pixels around until you drop in a clean frame.

**Category:** Plugins (Caddis Examples)

## How it works

Every frame, the node compares the source with the frame before it, block by block, to estimate how each block moved. Instead of showing the new frame, it pushes **last frame's result** along that motion — what a video player does when the keyframes have been removed. A little of each frame's real change (the *residual*) is painted on top, so new shapes smear in rather than appearing cleanly.

The node keeps its own previous result, so scrubbing anywhere gives the same picture as playing from the start.

## Parameters

| Param | What it does |
|---|---|
| **Clean Frame** | Drop a key where the mosh should restart from the real footage. The layer's first frame is always clean. |
| **Block Size** | Size of the motion blocks, in pixels. Bigger blocks give chunkier, more "codec" smears. |
| **Search Range** | How far (px) to look for each block's motion between frames. Raise it for fast footage. |
| **Motion** | Multiplies the estimated motion. Above 1 exaggerates the drag. |
| **Residual** | How much of each frame's real change paints onto the mosh. 0 is pure drag; 1 follows the footage more closely. |
| **Bleed** | Mixes the clean footage back in every frame. |

## Tips

- Footage with a cut or a big camera move moshes best: put a Clean Frame key just before the move.
- Expose **Motion** (E) and drive it from an audio-reactive or keyframed value for pulsing smears.
