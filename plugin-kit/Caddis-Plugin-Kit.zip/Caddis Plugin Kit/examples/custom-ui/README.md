# Custom UI — example plugin

A control and a viewer handle the plugin draws itself, written in Rust.

- `src/lib.rs` — the exports: `bands_draw` / `bands_event` / `bands_bake` (the Bands control) and `light_draw` / `light_event` (the light handle in the viewer)
- `plugin/` — the bundle: `plugin.json`, `logic.wasm`, the shader, help

```sh
./build.sh            # builds and copies plugin/logic.wasm
```

Plugins draw with Caddis's colour tokens only (`Token::Text`, `Accent`, …), so every plugin's controls look native.

The Bands control also answers keys: its manifest entry lists `"keys": ["left", "right"]`, and `bands_event` nudges the edge that was last pressed (or the whole band) on `Event::Key`.
