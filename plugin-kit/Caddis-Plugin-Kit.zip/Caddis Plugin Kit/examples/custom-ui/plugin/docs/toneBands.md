# Tone Bands

> Lights one band of brightness inside a spotlight you drag in the viewer.

The **Bands** control is drawn by the plugin: drag its two edges to choose which brightnesses light up; double-click it to reset. Select the node to see the light in the viewer: drag its centre, the handle on the ring for the radius, and the spoke for the angle.

| Param | What it does |
|---|---|
| **Bands** | The band of brightness that lights up. |
| **Center**, **Radius** | The light. |
| **Angle** | The light's direction (shown by the spoke). |
| **Boost** | How much brighter the band gets. |
