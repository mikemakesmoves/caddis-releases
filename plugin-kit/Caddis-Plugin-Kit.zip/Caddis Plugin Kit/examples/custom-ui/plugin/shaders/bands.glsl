// Tone Bands: brightens pixels whose brightness falls in the Bands control's
// band, inside the light the viewer handle draws. `bands_lut` is what the
// plugin's bake export produced (a 0–1 weight by brightness).
vec4 shade(vec2 uv) {
    vec4 c = texture(src, uv);
    float luma = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));
    float inBand = texture(bands_lut, vec2(luma, 0.5)).r;
    float d = distance(uv * iResolution, caddis_to_uv(center) * iResolution);
    float lit = 1.0 - smoothstep(radius * 0.8, radius, d);
    return vec4(c.rgb * (1.0 + inBand * lit * boost), c.a);
}
