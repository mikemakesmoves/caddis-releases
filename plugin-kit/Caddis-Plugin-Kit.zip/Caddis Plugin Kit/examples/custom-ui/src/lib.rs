//! Tone Bands — a control and a viewer handle the plugin draws itself.
//!
//! The Bands setting's value is plain text, "lo,hi" (0–1). Caddis stores it,
//! keys it, and folds a drag into one undo step; this module only draws it,
//! answers events with a new value, and bakes it into the lookup the shader
//! reads (`@param.bands`).

use caddis_plugin::*;

fn bands(req: &Request) -> (f64, f64) {
    let s = req.param_str("bands", "0.25,0.75");
    let mut it = s.split(',').filter_map(|x| x.trim().parse::<f64>().ok());
    let lo = it.next().unwrap_or(0.25).clamp(0.0, 1.0);
    let hi = it.next().unwrap_or(0.75).clamp(lo, 1.0);
    (lo, hi)
}

const PAD: f64 = 8.0;

fn bands_draw(req: &Request) -> Result<Response, String> {
    let [w, h] = req.ui_size();
    let (lo, hi) = bands(req);
    let x = |v: f64| PAD + v * (w - 2.0 * PAD);
    let mut d = DrawList::new();
    d.rect([0.0, 0.0, w, h], 3.0, Paint::fill(Token::Inset));
    // Quarter grid.
    for i in 1..4 {
        let gx = x(i as f64 / 4.0);
        d.line(
            [gx, PAD],
            [gx, h - PAD],
            Paint::stroke(Token::Subtle, 1.0).alpha(0.35),
        );
    }
    // A tone ramp along the bottom, as ten steps of the muted token.
    for i in 0..10 {
        let t = i as f64 / 10.0;
        d.rect(
            [x(t), h - PAD - 6.0, (w - 2.0 * PAD) / 10.0, 6.0],
            0.0,
            Paint::fill(Token::Muted).alpha(0.1 + t * 0.8),
        );
    }
    // The selected band.
    d.polygon(
        &[
            [x(lo), h - PAD - 8.0],
            [x(lo), PAD],
            [x(hi), PAD],
            [x(hi), h - PAD - 8.0],
        ],
        Paint::fill(Token::Accent).alpha(0.14),
    );
    // The input's brightness histogram, in Caddis's own look, behind the
    // band's edges (`"histogram": true` on the setting).
    d.histogram(
        [PAD, PAD, w - 2.0 * PAD, h - 2.0 * PAD - 8.0],
        HistogramChannel::Luma,
    );
    d.line(
        [x(lo), PAD],
        [x(lo), h - PAD - 8.0],
        Paint::stroke(Token::Accent, 1.2),
    );
    d.line(
        [x(hi), PAD],
        [x(hi), h - PAD - 8.0],
        Paint::stroke(Token::Accent, 1.2),
    );
    // The raw histogram is for numbers Caddis can't draw for you: here, how
    // much of the image falls inside the band.
    let mut label = format!("{:.0}–{:.0}%", lo * 100.0, hi * 100.0);
    if let Some([_, _, _, luma]) = req.ui_histogram() {
        let total: f64 = luma.iter().sum();
        let inside: f64 = luma
            .iter()
            .enumerate()
            .filter(|(i, _)| (lo..=hi).contains(&(*i as f64 / 255.0)))
            .map(|(_, v)| v)
            .sum();
        if total > 0.0 {
            label += &format!(" · {:.0}% of image", inside / total * 100.0);
        }
    }
    d.text(
        [x((lo + hi) / 2.0), PAD + 12.0],
        &label,
        10.0,
        Align::Center,
        Paint::fill(Token::Text),
    );
    // Grab the band's middle to move it whole (an area under the handles);
    // its edges are Caddis's edge bars and drag sideways.
    d.handle_area([x(lo), PAD, x(hi) - x(lo), h - 2.0 * PAD - 8.0], "band");
    d.handle_styled([x(lo), (h - 8.0) / 2.0], 10.0, "lo", HandleStyle::BarV);
    d.handle_styled([x(hi), (h - 8.0) / 2.0], 10.0, "hi", HandleStyle::BarV);
    Ok(Response::new().draw(d))
}

fn bands_event(req: &Request) -> Result<Response, String> {
    let [w, _] = req.ui_size();
    let (lo, hi) = bands(req);
    let v = |px: f64| ((px - PAD) / (w - 2.0 * PAD)).clamp(0.0, 1.0);
    let value = match req.event() {
        Some(Event::Drag { handle, pos, .. }) if handle == "lo" => {
            format!("{:.4},{hi:.4}", v(pos[0]).min(hi))
        }
        Some(Event::Drag { handle, pos, .. }) if handle == "hi" => {
            format!("{lo:.4},{:.4}", v(pos[0]).max(lo))
        }
        Some(Event::Drag { handle, step, .. }) if handle == "band" => {
            // Move both edges by the pointer's motion, keeping the width.
            let dv = step[0] / (w - 2.0 * PAD);
            let shift = dv.clamp(-lo, 1.0 - hi);
            format!("{:.4},{:.4}", lo + shift, hi + shift)
        }
        Some(Event::DoubleClick { .. }) => "0.25,0.75".into(),
        // Left / Right nudge whatever was last pressed: an edge, or the whole
        // band (its middle, or nothing in particular). The manifest lists
        // these two keys, so they are the only ones this control is sent.
        Some(Event::Key {
            key, handle, mods, ..
        }) => {
            let step = match key {
                Key::Left => -1.0,
                Key::Right => 1.0,
                _ => return Ok(Response::new()),
            } * if mods.shift { 0.1 } else { 0.01 };
            match handle.as_str() {
                "lo" => format!("{:.4},{hi:.4}", (lo + step).clamp(0.0, hi)),
                "hi" => format!("{lo:.4},{:.4}", (hi + step).clamp(lo, 1.0)),
                _ => {
                    let shift = step.clamp(-lo, 1.0 - hi);
                    format!("{:.4},{:.4}", lo + shift, hi + shift)
                }
            }
        }
        _ => return Ok(Response::new()),
    };
    // Answer with the new value AND the new drawing: no second round trip.
    let mut redraw = req.clone();
    if let Some(p) = redraw.params.iter_mut().find(|(k, _)| k == "bands") {
        p.1 = Value::String(value.clone());
    }
    let mut out = bands_draw(&redraw)?;
    out = out.value(&value);
    Ok(out)
}

fn bands_bake(req: &Request) -> Result<Response, String> {
    let (lo, hi) = bands(req);
    let soft = 0.04;
    let smooth = |a: f64, b: f64, x: f64| {
        let t = ((x - a) / (b - a)).clamp(0.0, 1.0);
        t * t * (3.0 - 2.0 * t)
    };
    let mut rgba = Vec::with_capacity(256 * 4);
    for i in 0..256 {
        let x = i as f64 / 255.0;
        let w = smooth(lo - soft, lo, x) * (1.0 - smooth(hi, hi + soft, x));
        rgba.extend_from_slice(&[w, w, w, 1.0]);
    }
    Ok(Response::new().bake(rgba))
}

/// The light handle in the viewer: centre, radius ring, angle spoke.
fn light_draw(req: &Request) -> Result<Response, String> {
    let c = match req.param("center") {
        Some(Value::Vec2(v)) => *v,
        _ => [0.0, 0.0],
    };
    let r = req.param_f64("radius", 200.0);
    let a = req.param_f64("angle", 0.0).to_radians();
    let px = req.ui_scale();
    let spoke = [c[0] + a.cos() * r, c[1] + a.sin() * r];
    let mut d = DrawList::new();
    d.ellipse(c, [r, r], Paint::stroke(Token::Gizmo, 1.5 * px).alpha(0.85));
    d.line(c, spoke, Paint::stroke(Token::Gizmo, 1.0 * px).alpha(0.85));
    d.handle(c, 6.0 * px, "center");
    d.handle(spoke, 6.0 * px, "angle");
    d.handle([c[0], c[1] - r], 6.0 * px, "radius");
    Ok(Response::new().draw(d))
}

fn light_event(req: &Request) -> Result<Response, String> {
    let c = match req.param("center") {
        Some(Value::Vec2(v)) => *v,
        _ => [0.0, 0.0],
    };
    let Some(Event::Drag {
        handle, pos, mods, ..
    }) = req.event()
    else {
        return Ok(Response::new());
    };
    let out = Response::new();
    Ok(match handle.as_str() {
        "center" => out.set("center", Value::Vec2(pos)),
        "radius" => out.set(
            "radius",
            Value::Scalar(((pos[0] - c[0]).hypot(pos[1] - c[1])).max(1.0)),
        ),
        "angle" => {
            let mut deg = (pos[1] - c[1]).atan2(pos[0] - c[0]).to_degrees();
            if mods.shift {
                deg = (deg / 15.0).round() * 15.0;
            }
            out.set("angle", Value::Scalar(deg))
        }
        _ => out,
    })
}

caddis_plugin::entry!(
    bands_draw => bands_draw,
    bands_event => bands_event,
    bands_bake => bands_bake,
    light_draw => light_draw,
    light_event => light_event
);
