# Pulse Glow

> CPU logic computes a value every frame and hands it to a GPU pass.

The plugin's WebAssembly writes the **Glow** param each frame (a sine at **Rate** Hz, scaled by **Depth**); the shader brightens the image by it. This is the pattern for anything a shader can't compute on its own — analysis, counting, state machines.
