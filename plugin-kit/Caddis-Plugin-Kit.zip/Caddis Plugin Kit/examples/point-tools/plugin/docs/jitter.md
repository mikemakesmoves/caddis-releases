# Point Jitter

> Moves every point a random amount — a Rust/WebAssembly logic example.

Each point's offset is keyed on its **id**, so a point keeps its jitter when others are added or removed upstream. With **Speed** above 0 the points glide to a new random offset that many times per second.

| Param | What it does |
|---|---|
| **Amount** | Largest offset, in pixels. |
| **Speed** | New random targets per second. 0 holds still. |
| **Seed** | A different random pattern. |
