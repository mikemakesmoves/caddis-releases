# Drift Particles

> A small particle system written as plugin logic — every source point emits particles that fall under gravity and fade out.

The particle population is the node's own **state**: Caddis hands last frame's particles to the plugin each frame, and replays from checkpoints when you scrub, so any frame looks the same however you got there.

| Param | What it does |
|---|---|
| **Births** | Particles per source point per frame. |
| **Speed** | Launch speed, px per second (randomised per particle). |
| **Gravity** | Constant acceleration, px per second². |
| **Life** | Frames before a particle disappears. Opacity fades over its life. |
| **Seed** | A different random pattern. |
