# Starburst

> A star polygon built on the CPU — a Rust/WebAssembly example that outputs a shape.

Wire it into **Draw Shape** like any shape source. Bounds and overscan follow the star's real size.
