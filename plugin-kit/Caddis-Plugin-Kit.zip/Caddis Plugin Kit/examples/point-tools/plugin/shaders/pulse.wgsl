fn shade(uv: vec2<f32>) -> vec4<f32> {
  let c = textureSample(src, samp, uv);
  return vec4<f32>(c.rgb * (1.0 + params.glow), c.a);
}
