//! Point Tools — the Caddis SDK's Rust logic example.
//!
//! Build: `cargo build --release --target wasm32-unknown-unknown`, then copy
//! `target/wasm32-unknown-unknown/release/point_tools.wasm` to
//! `plugin/logic.wasm` (or run `./build.sh`).

use caddis_plugin::*;

/// Push every point a random distance along a random direction. Randomness
/// keys on the point id, so a point keeps its jitter when others come and go.
fn jitter(req: &Request) -> Result<Response, String> {
    let Some(mut pts) = req.points("points").cloned() else {
        return Ok(Response::new().output("out", Value::Points(Points::default())));
    };
    let amount = req.param_f64("amount", 10.0);
    let seed = req.param_f64("seed", 1.0) as u64;
    let speed = req.param_f64("speed", 0.0);
    // Animated jitter: blend between two random offsets per whole step.
    let t = req.context.time * speed;
    let step = t.floor() as u64;
    let f = t - t.floor();
    let ease = f * f * (3.0 - 2.0 * f);
    for (i, p) in pts.positions.iter_mut().enumerate() {
        let id = pts.ids[i];
        let at = |k: u64| {
            let a = hash01(id, seed.wrapping_add(k * 2)) * core::f64::consts::TAU;
            let r = hash01(id, seed.wrapping_add(k * 2 + 1)) * amount;
            [a.cos() * r, a.sin() * r]
        };
        let (o0, o1) = (at(step), at(step + 1));
        p[0] += o0[0] + (o1[0] - o0[0]) * ease;
        p[1] += o0[1] + (o1[1] - o0[1]) * ease;
    }
    Ok(Response::new().output("out", Value::Points(pts)))
}

/// A star polygon as a closed shape, origin-centred.
fn starburst(req: &Request) -> Result<Response, String> {
    let n = req.param_f64("points", 7.0).round().clamp(3.0, 256.0) as usize;
    let outer = req.param_f64("outer", 200.0);
    let inner = req.param_f64("inner", 90.0);
    let spin = req.param_f64("rotation", 0.0).to_radians();
    let mut shape = Shape::default();
    let mut ids = Vec::with_capacity(n * 2);
    for i in 0..n * 2 {
        let r = if i % 2 == 0 { outer } else { inner };
        let a = spin - core::f64::consts::FRAC_PI_2 + i as f64 * core::f64::consts::PI / n as f64;
        ids.push(shape.points.push([a.cos() * r, a.sin() * r]));
    }
    let segments = (0..ids.len())
        .map(|i| Segment {
            a: ids[i],
            b: ids[(i + 1) % ids.len()],
            ctrl1: None,
            ctrl2: None,
        })
        .collect();
    shape.paths.push(Path {
        closed: true,
        segments,
        ..Default::default()
    });
    Ok(Response::new().output("out", Value::Shape(shape)))
}

/// Logic feeding a GPU pass: compute a pulsing strength on the CPU and hand
/// it to the shader as an override of the `glow` param.
fn pulse(req: &Request) -> Result<Response, String> {
    let rate = req.param_f64("rate", 1.0);
    let depth = req.param_f64("depth", 1.0);
    let v = 0.5 + 0.5 * (req.context.time * rate * core::f64::consts::TAU).sin();
    Ok(Response::new().uniform("glow", Value::Scalar(v * depth)))
}

/// A tiny particle system: every source point emits particles that fall
/// under gravity and die of old age. The population is the node's `@state` —
/// Caddis hands last frame's back each frame and replays from checkpoints on
/// a scrub, so this stays deterministic.
fn drift(req: &Request) -> Result<Response, String> {
    let mut pop = match req.input("@state") {
        Some(Value::Points(p)) => p.clone(),
        _ => Points::default(),
    };
    let fps = req.context.fps.max(1.0);
    let dt = 1.0 / fps;
    let gravity = req.param_vec2("gravity", [0.0, 300.0]);
    let speed = req.param_f64("speed", 120.0);
    let life = req.param_f64("life", 45.0).max(1.0);
    let births = req.param_f64("births", 2.0).round().max(0.0) as u32;
    let seed = req.param_f64("seed", 1.0) as u64;

    // Step the existing particles.
    {
        let n = pop.len();
        let vel = pop.vec2_column("velocity").clone();
        let mut new_vel = vel;
        for i in 0..n {
            new_vel[i][0] += gravity[0] * dt;
            new_vel[i][1] += gravity[1] * dt;
            pop.positions[i][0] += new_vel[i][0] * dt;
            pop.positions[i][1] += new_vel[i][1] * dt;
        }
        *pop.vec2_column("velocity") = new_vel;
        for a in pop.scalar_column("age").iter_mut() {
            *a += 1.0;
        }
    }
    let ages = pop.scalar_column("age").clone();
    pop.retain_rows(|i| ages[i] < life);

    // Births at every source point.
    if let Some(src) = req.points("source") {
        for (k, p) in src.positions.iter().enumerate() {
            for b in 0..births {
                let id = pop.push(*p);
                let r = hash01(id, seed ^ (src.ids[k] as u64) << 8 ^ b as u64);
                let a = r * core::f64::consts::TAU;
                let s = speed * (0.5 + hash01(id, seed + 7));
                let last = pop.len() - 1;
                pop.vec2_column("velocity")[last] = [a.cos() * s, a.sin() * s];
            }
        }
    }
    // `opacity` fades with age, so Draw Points shows the life cycle.
    let ages = pop.scalar_column("age").clone();
    *pop.scalar_column("opacity") = ages.iter().map(|a| 1.0 - a / life).collect();

    Ok(Response::new()
        .output("out", Value::Points(pop.clone()))
        .output("@state", Value::Points(pop)))
}

/// The jitter node's "New Seed" button: a different, repeatable seed. (The
/// sandbox has no clock or random numbers, so it's derived from the current
/// one.)
fn new_seed(req: &Request) -> Result<Response, String> {
    let seed = req.param_f64("seed", 1.0) as u64;
    let next = (seed.wrapping_mul(2654435761).wrapping_add(97) % 100_000) as f64;
    Ok(Response::new().set("seed", Value::Scalar(next)))
}

caddis_plugin::entry!(jitter => jitter, starburst => starburst, pulse => pulse, drift => drift, new_seed => new_seed);
