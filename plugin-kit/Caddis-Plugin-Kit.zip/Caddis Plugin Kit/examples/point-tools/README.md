# Point Tools (example)

Rust logic compiled to WebAssembly, packaged as a Caddis plugin.

- `src/lib.rs` — the three nodes' logic (`caddis-plugin` crate)
- `plugin/` — the bundle: `plugin.json`, `logic.wasm`, shaders, docs

```sh
rustup target add wasm32-unknown-unknown
./build.sh            # builds and copies plugin/logic.wasm
```

Link `plugin/` as a development folder in **Plugins › Manage Plugins… › Developer › Add Development Folder…**, or zip its contents into `point-tools.cadplugin`.
