#!/bin/sh
# Build the logic module into the plugin bundle folder.
set -e
cd "$(dirname "$0")"
cargo build --release --target wasm32-unknown-unknown
cp target/wasm32-unknown-unknown/release/point_tools.wasm plugin/logic.wasm
ls -l plugin/logic.wasm
